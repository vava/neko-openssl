value _BIO_new_connect(value host_port);
value _ERR_load_BIO_strings();
value _BIO_do_connect(value bp);
value _BIO_read(value b, value data, value len);