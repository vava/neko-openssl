__declspec(dllexport) value _HMAC(const value evp_md, const value key, value key_len,
								  		   const value d, value n, value md, value md_len);

//__declspec(dllexport) value _HMAC_EVP_sha1(value key,
//		   const value d, value md);