#ifdef WIN32
	#include "stdafx.h"
#endif

#include "neko.h"
#include "stdio.h"

