int mcon();
void n_hello();