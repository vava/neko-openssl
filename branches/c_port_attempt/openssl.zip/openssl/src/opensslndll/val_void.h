#define VAL_VOID NULL
