void n_hello();
int mcon();
