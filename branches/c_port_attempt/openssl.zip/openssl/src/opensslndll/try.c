#include "test.h"
#include "neko.h"
#include "stdio.h"
#include "_hmac.h"

int main() {
	int x;
	n_hello();
	x = mcon();
	printf ("mcon response = [%d]", x);
	return 0;
}
