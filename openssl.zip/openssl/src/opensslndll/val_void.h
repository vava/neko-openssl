# include "neko.h"
#define VAL_VOID val_null
