value _SSL_load_error_strings();
value _OpenSSL_add_all_algorithms();
value _SSL_set_bio(value s, value rbio, value wbio);
