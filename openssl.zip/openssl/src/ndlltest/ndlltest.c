#include "stdio.h"
#include "../opensslndll/test.h"

int main()
{
	printf ("Running mcon() :\n");
	mcon();
	return 0;
}

